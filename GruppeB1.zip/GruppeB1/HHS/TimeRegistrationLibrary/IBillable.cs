﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TimeRegistrationLibrary
{
    public interface IBillable
    {
        void SendTimeSheets();
    }
}
